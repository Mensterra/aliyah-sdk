"""
Version information for aliyah-sdk package.
"""

__version__ = "0.1.0"
